# CampusConnect — Web Security Practical Project (Part 2: Blue Team Focus)

**Team:**
- Muhammad Usman — 23F-0570
- Ahsan Niaz — 23F-0584
- Muhammad Tanveer — 23F-0543

FAST-NUCES CFD Campus — Information Security Practical Assignment

---

## Use Case

**CampusConnect** — a student portal where students can log in, browse
courses, search courses, read/post course reviews, and manage account
settings (email). This single use case is implemented TWICE:

- **`/vulnerable`** — deliberately insecure. Every required attack works
  end-to-end.
- **`/safe`** — the exact same features, hardened against every attack
  listed below.

## Tech Stack

- **Backend:** Node.js + Express
- **Database:** `sql.js` (pure WebAssembly SQLite — no native compilation
  required, works on any OS/Node version with zero build tools)
- **Frontend:** Plain HTML/CSS/JavaScript (no framework), dark maroon theme
- **Sessions:** Cookie-based, custom implementation (no third-party auth
  library) so the vulnerability/fix is visible in the code itself

## How to Run Both Versions

Each version is a fully separate, independently runnable app.

### Vulnerable version (port 3000)
```bash
cd vulnerable
npm install
npm start
```
Visit: http://localhost:3000

### Safe version (port 3001)
```bash
cd safe
npm install
npm start
```
Visit: http://localhost:3001

Both can run **at the same time** (different ports) for side-by-side
comparison.

**Seeded accounts (both versions):**
| Username | Password |
|---|---|
| ahsan | ahsan123 |
| usman | usman123 |
| tanveer | tanveer123 |
| admin | SuperSecretAdmin!2026 |

---

## Implemented Vulnerabilities & Fixes

### 1. Cross-Site Scripting (XSS) — all 3 types

| Type | Vulnerable version | Safe version |
|---|---|---|
| Reflected | `search.html?q=` echoed raw into `innerHTML` | Rendered via `textContent` — payload displays as plain text |
| Stored | Course reviews saved & rendered raw via `innerHTML` | Reviews rendered via `textContent` — stored payload stays inert |
| DOM-based | `location.hash` written into `innerHTML` on `dom.html`, purely client-side | Rendered via `textContent` |

Defense-in-depth: the safe version also sends a `Content-Security-Policy`
header restricting script sources.

### 2. CSRF

- **Vulnerable:** `/api/settings/update-email` trusts the session cookie
  alone — no token, no origin check, cookie has no `SameSite` restriction.
  A forged form on `/attacker/csrf.html` silently changes the victim's
  email.
- **Safe:** the same endpoint now requires a per-session CSRF token sent
  as an `X-CSRF-Token` header, issued at login and never embedded anywhere
  a cross-origin page could read it. The session cookie is also
  `HttpOnly` + `SameSite=Strict`, so it isn't even attached to cross-site
  requests. The same attacker page is included in `/safe/attacker/` to
  demonstrate the attack now failing.

### 3. SQL Injection — 3 levels

| Level | Vulnerable version | Safe version |
|---|---|---|
| Easy (login bypass) | Username/password concatenated directly into the SQL string — `admin' --` bypasses auth | Parameterized query (`?` placeholders) — payload treated as literal text |
| Intermediate (blind boolean) | `/api/courses/filter?instructor=` concatenated raw, only true/false leaked | Parameterized — always returns the real result, no oracle |
| Advanced (UNION chain) | `/api/courses/search-advanced?code=` concatenated raw — full chain: column count → table names (`sqlite_master`) → column names → data dump (usernames/passwords) | Parameterized — injection string is treated as a literal course code, no data ever leaks |

Bonus hardening in the safe version: passwords are stored as salted
`scrypt` hashes (Node's built-in `crypto` module) with a timing-safe
comparison, instead of plaintext.

---

## Payload & Screenshot Evidence

See the accompanying Word document / spreadsheet for the full
payload-and-screenshot table (one entry per vulnerability, each with the
exact payload used and screenshots for both the successful vulnerable-version
exploit and the corresponding safe-version failure).

## Project Structure
```
.
├── vulnerable/        # Insecure version (port 3000)
│   ├── server.js
│   ├── db/
│   ├── public/
│   └── attacker/csrf.html
├── safe/               # Hardened version (port 3001)
│   ├── server.js
│   ├── db/
│   ├── public/
│   └── attacker/csrf.html
└── README.md
```

## Academic Integrity

All vulnerabilities and fixes above were implemented genuinely and are
fully functional end-to-end — nothing is simulated, hardcoded, or faked.
