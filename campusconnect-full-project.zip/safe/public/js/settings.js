function csrfHeaders() {
  return { 'X-CSRF-Token': sessionStorage.getItem('csrfToken') || '' };
}

document.getElementById('emailForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const newEmail = document.getElementById('newEmail').value;
  const msg = document.getElementById('msg');
  msg.textContent = '';

  const res = await fetch('/api/settings/update-email', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...csrfHeaders() },
    body: JSON.stringify({ newEmail })
  });
  const data = await res.json();

  const div = document.createElement('div');
  if (data.success) {
    div.className = 'msg ok';
    div.textContent = `Email updated to ${data.newEmail}`;
  } else {
    div.className = 'msg error';
    div.textContent = data.error || 'Update failed';
  }
  msg.append(div);
});
