function csrfHeaders() {
  return { 'X-CSRF-Token': sessionStorage.getItem('csrfToken') || '' };
}

async function loadSession() {
  const res = await fetch('/api/me');
  const data = await res.json();
  const info = document.getElementById('userInfo');
  info.textContent = ''; // FIX: clear via textContent, never innerHTML
  if (data.loggedIn) {
    sessionStorage.setItem('csrfToken', data.csrfToken); // refresh token on each page load
    info.textContent = `Logged in as ${data.user.username} (${data.user.role}) — email: ${data.user.email}`;
  } else {
    const link = document.createElement('a');
    link.href = 'index.html';
    link.textContent = 'Login here';
    info.append('Not logged in. ', link, '.');
  }
}

async function loadCourses() {
  const res = await fetch('/api/courses');
  const data = await res.json();
  const list = document.getElementById('courseList');
  list.textContent = '';
  data.courses.forEach(c => {
    const item = document.createElement('div');
    item.className = 'course-item';
    const strong = document.createElement('strong');
    strong.textContent = c.code;
    item.append(strong, ` — ${c.title} (${c.instructor})`, document.createElement('br'));
    const a = document.createElement('a');
    a.href = `course.html?id=${encodeURIComponent(c.id)}`;
    a.textContent = 'View reviews';
    item.append(a);
    list.append(item);
  });
}

document.getElementById('logoutLink').addEventListener('click', async (e) => {
  e.preventDefault();
  await fetch('/api/logout', { method: 'POST', headers: csrfHeaders() });
  sessionStorage.removeItem('csrfToken');
  window.location.href = 'index.html';
});

loadSession();
loadCourses();
