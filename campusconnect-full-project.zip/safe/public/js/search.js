function getParam(name) {
  const params = new URLSearchParams(window.location.search);
  return params.get(name) || '';
}

async function runQuery(q) {
  const res = await fetch('/api/search?q=' + encodeURIComponent(q));
  const data = await res.json();

  // FIX (Reflected XSS): textContent only. Any HTML in data.echo is shown
  // as literal characters, never parsed/executed as markup.
  document.getElementById('echoLine').textContent = 'You searched for: ' + data.echo;

  const results = document.getElementById('results');
  results.textContent = '';
  if (!data.results.length) {
    const p = document.createElement('p');
    p.textContent = 'No results.';
    results.append(p);
  } else {
    data.results.forEach(c => {
      const item = document.createElement('div');
      item.className = 'course-item';
      const strong = document.createElement('strong');
      strong.textContent = c.code;
      item.append(strong, ` — ${c.title} (${c.instructor})`);
      results.append(item);
    });
  }
}

function doSearch() {
  const q = document.getElementById('q').value;
  const url = new URL(window.location.href);
  url.searchParams.set('q', q);
  window.history.replaceState({}, '', url);
  runQuery(q);
}

window.addEventListener('DOMContentLoaded', () => {
  const q = getParam('q');
  document.getElementById('q').value = q;
  if (q) runQuery(q);
});
