// FIX (DOM-based XSS): untrusted data (location.hash) is rendered with
// textContent, a safe sink that never parses its argument as HTML/JS.
function renderBanner() {
  const name = decodeURIComponent(window.location.hash.slice(1)) || 'Guest';
  document.getElementById('banner').textContent = `Welcome back, ${name}!`;
}

window.addEventListener('DOMContentLoaded', renderBanner);
window.addEventListener('hashchange', renderBanner);
