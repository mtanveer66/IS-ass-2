function csrfHeaders() {
  return { 'X-CSRF-Token': sessionStorage.getItem('csrfToken') || '' };
}

function getCourseId() {
  return new URLSearchParams(window.location.search).get('id');
}
const courseId = getCourseId();

async function loadCourse() {
  const res = await fetch('/api/courses');
  const data = await res.json();
  const course = data.courses.find(c => String(c.id) === String(courseId));
  if (course) {
    document.getElementById('courseTitle').textContent = `${course.code} — ${course.title} (${course.instructor})`;
  }
}

async function loadReviews() {
  const res = await fetch(`/api/courses/${encodeURIComponent(courseId)}/reviews`);
  const data = await res.json();
  const container = document.getElementById('reviews');
  container.textContent = '';
  if (!data.reviews.length) {
    const p = document.createElement('p');
    p.textContent = 'No reviews yet.';
    container.append(p);
    return;
  }
  // FIX (Stored XSS): each review is built with textContent, never
  // innerHTML. Whatever HTML/JS a reviewer typed is shown as inert text.
  data.reviews.forEach(r => {
    const div = document.createElement('div');
    div.className = 'review';
    const strong = document.createElement('strong');
    strong.textContent = r.username + ': ';
    div.append(strong, r.comment); // text node, not parsed as HTML
    container.append(div);
  });
}

async function submitReview() {
  const comment = document.getElementById('comment').value;
  const msg = document.getElementById('reviewMsg');
  msg.textContent = '';
  const res = await fetch(`/api/courses/${encodeURIComponent(courseId)}/reviews`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...csrfHeaders() },
    body: JSON.stringify({ comment })
  });
  if (res.status === 401) {
    msg.textContent = 'You must be logged in to post a review.';
    return;
  }
  document.getElementById('comment').value = '';
  loadReviews();
}

loadCourse();
loadReviews();
