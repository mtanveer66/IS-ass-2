document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const msg = document.getElementById('msg');

  const res = await fetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });
  const data = await res.json();

  msg.textContent = ''; // FIX: never innerHTML on anything derived from input/response
  if (data.success) {
    const okDiv = document.createElement('div');
    okDiv.className = 'msg ok';
    okDiv.textContent = `Logged in as ${data.user.username} (${data.user.role})`;
    msg.appendChild(okDiv);
    // FIX: CSRF token issued at login is kept in sessionStorage (JS-readable
    // by this origin only) -- never embedded in the DOM or sent anywhere
    // except as our own X-CSRF-Token header on state-changing requests.
    sessionStorage.setItem('csrfToken', data.csrfToken);
    setTimeout(() => (window.location.href = 'dashboard.html'), 600);
  } else {
    const errDiv = document.createElement('div');
    errDiv.className = 'msg error';
    errDiv.textContent = data.message || 'Login failed';
    msg.appendChild(errDiv);
  }
});
