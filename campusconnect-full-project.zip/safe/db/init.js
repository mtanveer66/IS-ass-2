// db/init.js (SAFE VERSION)
// Same schema and seed data as the vulnerable version, EXCEPT passwords are
// now stored as salted hashes (Node's built-in crypto.scrypt) instead of
// plaintext. This mirrors a real-world fix: even if the DB is dumped via
// some other flaw, raw passwords are not exposed.

const path = require('path');
const crypto = require('crypto');
const { openDatabase } = require('./sqlWrapper');

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function verifyPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  const candidate = crypto.scryptSync(password, salt, 64).toString('hex');
  // timing-safe comparison
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(candidate, 'hex');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

async function initDb() {
  const db = await openDatabase(path.join(__dirname, 'campus.db'));

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL,
      password TEXT NOT NULL,
      email TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'student'
    );

    CREATE TABLE IF NOT EXISTS courses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL,
      title TEXT NOT NULL,
      instructor TEXT NOT NULL,
      description TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER NOT NULL,
      username TEXT NOT NULL,
      comment TEXT NOT NULL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);

  const userCount = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
  if (userCount === 0) {
    const insertUser = db.prepare(
      'INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)'
    );
    insertUser.run('ahsan', hashPassword('ahsan123'), 'ahsan@fastcfd.edu.pk', 'student');
    insertUser.run('usman', hashPassword('usman123'), 'usman@fastcfd.edu.pk', 'student');
    insertUser.run('tanveer', hashPassword('tanveer123'), 'tanveer@fastcfd.edu.pk', 'student');
    insertUser.run('admin', hashPassword('SuperSecretAdmin!2026'), 'admin@fastcfd.edu.pk', 'admin');
  }

  const courseCount = db.prepare('SELECT COUNT(*) AS c FROM courses').get().c;
  if (courseCount === 0) {
    const insertCourse = db.prepare(
      'INSERT INTO courses (code, title, instructor, description) VALUES (?, ?, ?, ?)'
    );
    insertCourse.run('AL2002', 'Artificial Intelligence Lab', 'Dr. Farooq', 'Hands-on AI lab covering search, ML basics, and agents.');
    insertCourse.run('CL2001', 'Data Structures', 'Dr. Mehwish', 'Core data structures and algorithms using C++.');
    insertCourse.run('CS3203', 'Theory of Automata', 'Dr. Khalid', 'Formal languages, automata, and computability.');
    insertCourse.run('CS4101', 'Information Security', 'Dr. Sana', 'Web security, cryptography, and secure system design.');
  }

  const reviewCount = db.prepare('SELECT COUNT(*) AS c FROM reviews').get().c;
  if (reviewCount === 0) {
    const insertReview = db.prepare(
      'INSERT INTO reviews (course_id, username, comment) VALUES (?, ?, ?)'
    );
    insertReview.run(1, 'ahsan', 'Great hands-on labs, learned a lot about agents.');
    insertReview.run(2, 'usman', 'Tough but fair, recursion section was the hardest.');
  }

  return db;
}

module.exports = { initDb, verifyPassword };
