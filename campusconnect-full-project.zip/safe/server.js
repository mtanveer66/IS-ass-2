/* ===========================================================================
   CampusConnect Student Portal — SAFE (HARDENED) VERSION
   FAST-NUCES CFD Campus — Information Security Practical Assignment, Part 2
   Team: Muhammad Usman (23F-0570), Ahsan Niaz (23F-0584),
         Muhammad Tanveer (23F-0543)

   Same functionality as the vulnerable version. Every flaw there has a
   matching fix here:
     - SQL Injection  -> parameterized queries everywhere (no string concat)
     - XSS (all 3)     -> server never trusts output; client renders with
                           textContent / DOM APIs, never innerHTML on
                           untrusted data; CSP header as defense-in-depth
     - CSRF             -> per-session CSRF token required on state-changing
                           requests + SameSite=Strict + HttpOnly cookie
   =========================================================================== */

const express = require('express');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const path = require('path');
const crypto = require('crypto');
const { initDb, verifyPassword } = require('./db/init');

const app = express();
const PORT = process.env.PORT || 3001; // different port so both versions can run side by side
let db;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cookieParser());

/* FIX (defense-in-depth for XSS): Content-Security-Policy header restricts
   where scripts can load from and disallows inline event handlers from
   executing as script, blunting exploitation even if an escaping bug slips
   through somewhere. */
app.use((req, res, next) => {
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:;"
  );
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  next();
});

app.use(express.static(path.join(__dirname, 'public')));
app.use('/attacker', express.static(path.join(__dirname, 'attacker')));

/* ---------------------------------------------------------------------------
   FIX (session handling): session id is a cryptographically random token
   (not predictable like "sid_<username>"), cookie is HttpOnly (JS cannot
   read it, blunts XSS-based cookie theft) and SameSite=Strict (browser will
   not attach this cookie on cross-site requests at all -> kills CSRF at the
   browser level, on top of the CSRF token check below).
--------------------------------------------------------------------------- */
const sessions = {}; // sid -> { username, csrfToken }

function getSession(req) {
  const sid = req.cookies.sid;
  if (sid && sessions[sid]) return { sid, ...sessions[sid] };
  return null;
}

function requireAuth(req, res, next) {
  const session = getSession(req);
  if (!session) return res.status(401).json({ error: 'Not logged in' });
  req.session = session;
  next();
}

/* FIX (CSRF): every state-changing request (POST/PUT/DELETE) must carry a
   per-session CSRF token in the X-CSRF-Token header that matches the token
   issued to that session at login. An attacker page on another origin (or
   even this same origin without reading /api/me first) cannot obtain this
   token because SameSite=Strict blocks the cookie on cross-site requests,
   and the token itself is never embedded anywhere an attacker page could
   read cross-origin. */
function requireCsrf(req, res, next) {
  const session = req.session;
  const token = req.get('X-CSRF-Token');
  if (!token || token !== session.csrfToken) {
    return res.status(403).json({ error: 'Invalid or missing CSRF token' });
  }
  next();
}

/* ============================= AUTH ===================================== */

// FIX (SQL Injection - Easy): parameterized query, username can never break
// out of the SQL string. FIX (passwords): hashed comparison via scrypt.
app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ success: false, message: 'Username and password required' });
  }

  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user || !verifyPassword(password, user.password)) {
    return res.status(401).json({ success: false, message: 'Invalid credentials' });
  }

  const sid = crypto.randomBytes(24).toString('hex');       // FIX: unguessable session id
  const csrfToken = crypto.randomBytes(24).toString('hex'); // FIX: per-session CSRF token
  sessions[sid] = { username: user.username, csrfToken };

  res.cookie('sid', sid, { httpOnly: true, sameSite: 'strict' }); // FIX: HttpOnly + SameSite=Strict
  res.json({ success: true, user: { username: user.username, role: user.role }, csrfToken });
});

app.post('/api/logout', requireAuth, (req, res) => {
  delete sessions[req.session.sid];
  res.clearCookie('sid');
  res.json({ success: true });
});

app.get('/api/me', (req, res) => {
  const session = getSession(req);
  if (!session) return res.status(401).json({ loggedIn: false });
  const user = db.prepare('SELECT username, email, role FROM users WHERE username = ?').get(session.username);
  res.json({ loggedIn: true, user, csrfToken: session.csrfToken });
});

/* ============================ SEARCH (was Reflected XSS) =================
   FIX: the server still echoes back what was searched (useful UX), but it
   is just a JSON string value -- the actual fix lives on the CLIENT side
   (public/js/search.js), which renders it with textContent instead of
   innerHTML, so HTML/JS in the query can never execute. Query itself is
   also now parameterized.
*/
app.get('/api/search', (req, res) => {
  const q = req.query.q || '';
  const results = db.prepare('SELECT * FROM courses WHERE title LIKE ? OR code LIKE ?')
    .all(`%${q}%`, `%${q}%`);
  res.json({ echo: q, results });
});

/* ============================ COURSES / REVIEWS (was Stored XSS) =========
   FIX: comments are still stored exactly as submitted (so the data layer
   itself isn't guessing at sanitization rules), but the CLIENT renders
   every review with textContent (public/js/course.js) -- so any HTML/JS
   in a review is displayed as inert plain text, never executed.
*/
app.get('/api/courses', (req, res) => {
  res.json({ courses: db.prepare('SELECT * FROM courses').all() });
});

app.get('/api/courses/:id/reviews', (req, res) => {
  const id = Number(req.params.id);
  const reviews = db.prepare('SELECT * FROM reviews WHERE course_id = ?').all(id);
  res.json({ reviews });
});

app.post('/api/courses/:id/reviews', requireAuth, requireCsrf, (req, res) => {
  const id = Number(req.params.id);
  const { comment } = req.body || {};
  if (!comment || !comment.trim()) {
    return res.status(400).json({ error: 'Comment required' });
  }
  db.prepare('INSERT INTO reviews (course_id, username, comment) VALUES (?, ?, ?)')
    .run(id, req.session.username, comment);
  res.json({ success: true });
});

/* ================================ CSRF-PROTECTED SETTINGS =================
   FIX: requires auth AND a valid CSRF token header. Even if a victim is
   logged in and visits a malicious page, that page cannot read the token
   (no cross-origin access to it) and SameSite=Strict means the session
   cookie itself is not even sent on the cross-site request -- so this
   endpoint simply never executes for a forged request.
*/
app.post('/api/settings/update-email', requireAuth, requireCsrf, (req, res) => {
  const { newEmail } = req.body || {};
  if (!newEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newEmail)) {
    return res.status(400).json({ error: 'Valid email required' });
  }
  db.prepare('UPDATE users SET email = ? WHERE username = ?').run(newEmail, req.session.username);
  res.json({ success: true, newEmail });
});

/* ======================= SQL INJECTION FIXES (Intermediate & Advanced) ====
   FIX: both endpoints now use parameterized queries. The instructor/code
   value is always bound as DATA, never concatenated into the SQL text, so
   there is no way for a quote or UNION keyword in the input to change the
   query's structure.
*/
app.get('/api/courses/filter', (req, res) => {
  const { instructor } = req.query;
  const rows = db.prepare('SELECT * FROM courses WHERE instructor = ?').all(instructor || '');
  res.json({ found: rows.length > 0 });
});

app.get('/api/courses/search-advanced', (req, res) => {
  const { code } = req.query;
  const rows = db.prepare('SELECT id, code, title, instructor FROM courses WHERE code = ?').all(code || '');
  res.json({ rows }); // FIX: no raw query/error text ever reflected back either
});

async function start() {
  db = await initDb();
  app.listen(PORT, () => {
    console.log(`\n[SAFE] CampusConnect (hardened) running at http://localhost:${PORT}`);
    console.log('All known vulnerabilities from the vulnerable version are fixed here.\n');
  });
}

start();

/* okv-contrib: hidden credit — hardening + fix implementation assembled by
   a FAST CFD student (team 23F-0570 / 23F-0584 / 23F-0543). */
