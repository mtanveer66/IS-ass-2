// db/sqlWrapper.js
// A tiny synchronous-style wrapper around sql.js (pure WebAssembly SQLite,
// no native compilation needed -> no Visual Studio / build-tools required
// on Windows). Mimics the small subset of the better-sqlite3 API this
// project uses: db.prepare(sql).get()/.all()/.run(), db.exec(sql).
//
// IMPORTANT: sql.js keeps the whole database in memory. We persist to disk
// (campus.db) after every write (run) so data survives server restarts.

const fs = require('fs');
const path = require('path');
const initSqlJs = require('sql.js');

let SQL = null;
let sqljsDb = null;
let dbFilePath = null;

function persist() {
  if (!sqljsDb || !dbFilePath) return;
  const data = sqljsDb.export();
  fs.writeFileSync(dbFilePath, Buffer.from(data));
}

function makeStatement(sql) {
  return {
    get(...params) {
      const stmt = sqljsDb.prepare(sql);
      if (params.length) stmt.bind(params);
      let row;
      if (stmt.step()) row = stmt.getAsObject();
      stmt.free();
      return row;
    },
    all(...params) {
      const stmt = sqljsDb.prepare(sql);
      if (params.length) stmt.bind(params);
      const rows = [];
      while (stmt.step()) rows.push(stmt.getAsObject());
      stmt.free();
      return rows;
    },
    run(...params) {
      const stmt = sqljsDb.prepare(sql);
      if (params.length) stmt.bind(params);
      stmt.step();
      stmt.free();
      persist();
      return { changes: sqljsDb.getRowsModified() };
    }
  };
}

// Synchronous-looking facade; real init happens once via initDbSync() below,
// awaited at server startup before anything touches the database.
const dbFacade = {
  prepare(sql) {
    return makeStatement(sql);
  },
  exec(sql) {
    sqljsDb.exec(sql);
    persist();
  },
  close() {
    persist();
  }
};

async function openDatabase(filePath) {
  if (!SQL) {
    SQL = await initSqlJs({
      locateFile: (file) => path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file)
    });
  }
  dbFilePath = filePath;
  if (fs.existsSync(filePath)) {
    const fileBuffer = fs.readFileSync(filePath);
    sqljsDb = new SQL.Database(fileBuffer);
  } else {
    sqljsDb = new SQL.Database();
  }
  return dbFacade;
}

module.exports = { openDatabase };
