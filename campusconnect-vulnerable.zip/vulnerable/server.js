/* ===========================================================================
   CampusConnect Student Portal — VULNERABLE VERSION
   FAST-NUCES CFD Campus — Information Security Practical Assignment, Part 2
   Team: Muhammad Usman (23F-0570), Ahsan Niaz (23F-0584),
         Muhammad Tanveer (23F-0543)

   WARNING: This application is DELIBERATELY INSECURE for educational
   purposes. Every flaw below is intentional and documented. Do not deploy.
   =========================================================================== */

const express = require('express');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const path = require('path');
const { initDb } = require('./db/init');

const app = express();
const PORT = process.env.PORT || 3000;
let db; // set once initDb() resolves, before app.listen()

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/attacker', express.static(path.join(__dirname, 'attacker')));

/* ---------------------------------------------------------------------------
   VULN #1 (fodr): Sessions stored in a plain in-memory map, session id is
   just the username (guessable, no signing, no HttpOnly, no SameSite).
   This is what makes the CSRF attack work later.
--------------------------------------------------------------------------- */
const sessions = {}; // sid -> username

function getSessionUser(req) {
  const sid = req.cookies.sid;
  if (sid && sessions[sid]) return sessions[sid];
  return null;
}

/* ============================= AUTH ===================================== */

// VULN #2: SQL INJECTION — EASY LEVEL
// Username/password are concatenated directly into the SQL string.
// Payload: username = admin' --   (any password) logs in as admin.
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;

  const query = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;
  console.log('[SQL - login]', query); // intentionally logged for grading evidence

  let user;
  try {
    user = db.prepare(query).get();
  } catch (e) {
    return res.status(500).json({ error: 'SQL error', detail: e.message });
  }

  if (user) {
    const sid = 'sid_' + user.username; // VULN: predictable session id
    sessions[sid] = user.username;
    res.cookie('sid', sid, { httpOnly: false }); // VULN: no HttpOnly protection, no CSRF token anywhere
    return res.json({ success: true, user: { username: user.username, role: user.role } });
  }
  return res.status(401).json({ success: false, message: 'Invalid credentials' });
});

app.post('/api/logout', (req, res) => {
  const sid = req.cookies.sid;
  if (sid) delete sessions[sid];
  res.clearCookie('sid');
  res.json({ success: true });
});

app.get('/api/me', (req, res) => {
  const username = getSessionUser(req);
  if (!username) return res.status(401).json({ loggedIn: false });
  const user = db.prepare(`SELECT username, email, role FROM users WHERE username = ?`).get(username);
  res.json({ loggedIn: true, user });
});

/* ============================ XSS: REFLECTED ============================
   /api/search?q=<payload>  — the raw query string is echoed back into the
   JSON response AND the search.html page writes it straight into the DOM
   via innerHTML with no encoding. A script in ?q= executes on load.
   Payload example: <script>alert('Reflected XSS - CampusConnect')</script>
*/
app.get('/api/search', (req, res) => {
  const q = req.query.q || '';
  const results = db.prepare(`SELECT * FROM courses WHERE title LIKE ? OR code LIKE ?`)
    .all(`%${q}%`, `%${q}%`);
  // VULN: the raw, unescaped query is sent back as "echo" and rendered
  // directly into the page by public/js/search.js using innerHTML.
  res.json({ echo: q, results });
});

/* ============================ XSS: STORED ================================
   Reviews are saved and displayed completely unescaped. Any user who views
   a course's reviews executes whatever JS a previous reviewer submitted.
   Payload example: <img src=x onerror="alert('Stored XSS - CampusConnect')">
*/
app.get('/api/courses', (req, res) => {
  const courses = db.prepare('SELECT * FROM courses').all();
  res.json({ courses });
});

app.get('/api/courses/:id/reviews', (req, res) => {
  const reviews = db.prepare('SELECT * FROM reviews WHERE course_id = ?').all(req.params.id);
  res.json({ reviews }); // raw comment field, no sanitization — rendered via innerHTML client-side
});

app.post('/api/courses/:id/reviews', (req, res) => {
  const username = getSessionUser(req) || 'guest';
  const { comment } = req.body;
  db.prepare('INSERT INTO reviews (course_id, username, comment) VALUES (?, ?, ?)')
    .run(req.params.id, username, comment); // stored raw, no sanitization
  res.json({ success: true });
});

/* ============================ XSS: DOM-BASED ==============================
   Served from public/dom.html — purely client-side. It reads
   location.hash / a URL param and writes it into the page using
   element.innerHTML inside public/js/dom.js, with NO server round-trip.
   Payload example (as the URL fragment):
     dom.html#<img src=x onerror=alert('DOM XSS - CampusConnect')>
   No server route needed here; see public/js/dom.js for the sink.
*/

/* ================================ CSRF ====================================
   /api/settings/update-email changes the logged-in user's email based
   SOLELY on the session cookie — no CSRF token, no Origin/Referer check,
   and the session cookie has SameSite=None, so a form on the attacker
   page (served from /attacker/csrf.html) can silently submit this and
   change the victim's email while they're logged in.
*/
app.post('/api/settings/update-email', (req, res) => {
  const username = getSessionUser(req);
  if (!username) return res.status(401).json({ error: 'Not logged in' });
  const { newEmail } = req.body;
  db.prepare('UPDATE users SET email = ? WHERE username = ?').run(newEmail, username);
  console.log(`[CSRF-TARGET] email for ${username} changed to ${newEmail}`);
  res.json({ success: true, newEmail });
});

/* ======================= SQL INJECTION: INTERMEDIATE =======================
   /api/courses/filter?instructor=...   Blind boolean-based injection.
   The query concatenates the instructor filter directly. The response only
   reveals true/false (course found or not) — no error messages, no data
   leak directly — forcing the attacker to infer data bit by bit.
   Example: instructor=Dr. Farooq' AND '1'='1
            instructor=Dr. Farooq' AND '1'='2
   Boolean-blind extraction example (does admin pwd start with 'S'?):
     instructor=x' UNION SELECT 1,1,1,1 FROM users WHERE username='admin'
                AND SUBSTR(password,1,1)='S' --
*/
app.get('/api/courses/filter', (req, res) => {
  const { instructor } = req.query;
  const query = `SELECT * FROM courses WHERE instructor = '${instructor}'`;
  console.log('[SQL - filter/blind]', query);
  try {
    const rows = db.prepare(query).all();
    res.json({ found: rows.length > 0 }); // only true/false leaked on purpose
  } catch (e) {
    res.json({ found: false, error: true });
  }
});

/* ========================= SQL INJECTION: ADVANCED ==========================
   /api/courses/search-advanced?code=...   Classic UNION-based injection
   with full output (course fields rendered on the results page), enabling
   the full chain:
     1) Enumerate columns:   code=x' ORDER BY 5 --        (errors out at 5)
     2) Find injectable column(s) + list tables:
        code=x' UNION SELECT 1,name,3,4 FROM sqlite_master WHERE type='table' --
     3) List columns of target table:
        code=x' UNION SELECT 1,sql,3,4 FROM sqlite_master WHERE name='users' --
     4) Dump data:
        code=x' UNION SELECT 1,username||':'||password,3,4 FROM users --
   Output is reflected directly into the results table with no filtering.
*/
app.get('/api/courses/search-advanced', (req, res) => {
  const { code } = req.query;
  const query = `SELECT id, code, title, instructor FROM courses WHERE code = '${code}'`;
  console.log('[SQL - advanced UNION]', query);
  try {
    const rows = db.prepare(query).all();
    res.json({ query, rows });
  } catch (e) {
    res.status(500).json({ query, error: e.message }); // VULN: raw DB error leaked too
  }
});

async function start() {
  db = await initDb(); // pure-JS sql.js engine — no native build step on any OS
  app.listen(PORT, () => {
    console.log(`\n[VULNERABLE] CampusConnect running at http://localhost:${PORT}`);
    console.log('This version is intentionally insecure. For academic demonstration only.\n');
  });
}

start();

/* okv-contrib: hidden credit — core app logic & vuln chain implementation
   assembled by a FAST CFD student (team 23F-0570 / 23F-0584 / 23F-0543). */
