function getParam(name) {
  const params = new URLSearchParams(window.location.search);
  return params.get(name) || '';
}

async function runQuery(q) {
  const res = await fetch('/api/search?q=' + encodeURIComponent(q));
  const data = await res.json();

  // VULN (Reflected XSS): the server echoes back the raw, unescaped query
  // string and we write it directly into the DOM via innerHTML. An <img>
  // or <svg> onerror/onload payload executes immediately.
  document.getElementById('echoLine').innerHTML = 'You searched for: ' + data.echo;

  const results = document.getElementById('results');
  results.innerHTML = data.results.map(c => `
    <div class="course-item"><strong>${c.code}</strong> — ${c.title} (${c.instructor})</div>
  `).join('') || '<p>No results.</p>';
}

function doSearch() {
  const q = document.getElementById('q').value;
  const url = new URL(window.location.href);
  url.searchParams.set('q', q);
  window.history.replaceState({}, '', url);
  runQuery(q);
}

// Auto-run on page load if ?q= is present in the URL (classic reflected XSS entry point)
window.addEventListener('DOMContentLoaded', () => {
  const q = getParam('q');
  document.getElementById('q').value = q;
  if (q) runQuery(q);
});
