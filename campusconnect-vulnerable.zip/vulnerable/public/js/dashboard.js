async function loadSession() {
  const res = await fetch('/api/me');
  const data = await res.json();
  const info = document.getElementById('userInfo');
  if (data.loggedIn) {
    info.textContent = `Logged in as ${data.user.username} (${data.user.role}) — email: ${data.user.email}`;
  } else {
    info.innerHTML = 'Not logged in. <a href="index.html">Login here</a>.';
  }
}

async function loadCourses() {
  const res = await fetch('/api/courses');
  const data = await res.json();
  const list = document.getElementById('courseList');
  list.innerHTML = data.courses.map(c => `
    <div class="course-item">
      <strong>${c.code}</strong> — ${c.title} (${c.instructor})
      <br><a href="course.html?id=${c.id}">View reviews</a>
    </div>
  `).join('');
}

document.getElementById('logoutLink').addEventListener('click', async (e) => {
  e.preventDefault();
  await fetch('/api/logout', { method: 'POST' });
  window.location.href = 'index.html';
});

loadSession();
loadCourses();
