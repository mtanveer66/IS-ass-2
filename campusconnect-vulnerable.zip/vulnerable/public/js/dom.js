// VULN (DOM-based XSS): untrusted data (location.hash) flows directly into
// a dangerous sink (innerHTML) with no server round-trip and no sanitization.
function renderBanner() {
  const name = decodeURIComponent(window.location.hash.slice(1)) || 'Guest';
  document.getElementById('banner').innerHTML = `Welcome back, ${name}!`;
}

window.addEventListener('DOMContentLoaded', renderBanner);
window.addEventListener('hashchange', renderBanner);
