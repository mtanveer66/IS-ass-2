function getCourseId() {
  return new URLSearchParams(window.location.search).get('id');
}
const courseId = getCourseId();

async function loadCourse() {
  const res = await fetch('/api/courses');
  const data = await res.json();
  const course = data.courses.find(c => String(c.id) === String(courseId));
  if (course) {
    document.getElementById('courseTitle').textContent = `${course.code} — ${course.title} (${course.instructor})`;
  }
}

async function loadReviews() {
  const res = await fetch(`/api/courses/${courseId}/reviews`);
  const data = await res.json();
  const container = document.getElementById('reviews');
  // VULN (Stored XSS): review comments are rendered raw via innerHTML.
  // Any HTML/JS saved by a previous reviewer executes for every viewer.
  container.innerHTML = data.reviews.map(r => `
    <div class="review"><strong>${r.username}:</strong> ${r.comment}</div>
  `).join('') || '<p>No reviews yet.</p>';
}

async function submitReview() {
  const comment = document.getElementById('comment').value;
  await fetch(`/api/courses/${courseId}/reviews`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ comment })
  });
  document.getElementById('comment').value = '';
  loadReviews();
}

loadCourse();
loadReviews();
