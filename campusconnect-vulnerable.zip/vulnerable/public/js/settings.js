document.getElementById('emailForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const newEmail = document.getElementById('newEmail').value;
  const res = await fetch('/api/settings/update-email', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ newEmail })
  });
  const data = await res.json();
  const msg = document.getElementById('msg');
  if (data.success) {
    msg.innerHTML = `<div class="msg ok">Email updated to ${data.newEmail}</div>`;
  } else {
    msg.innerHTML = `<div class="msg error">${data.error || 'Update failed'}</div>`;
  }
});
