async function runFilter() {
  const instructor = document.getElementById('instructor').value;
  const res = await fetch('/api/courses/filter?instructor=' + encodeURIComponent(instructor));
  const data = await res.json();
  document.getElementById('filterResult').textContent =
    'Result: ' + (data.found ? 'TRUE (match found)' : 'FALSE (no match)');
}

async function runAdvanced() {
  const code = document.getElementById('code').value;
  const res = await fetch('/api/courses/search-advanced?code=' + encodeURIComponent(code));
  const data = await res.json();
  document.getElementById('advResult').textContent = JSON.stringify(data, null, 2);
}
